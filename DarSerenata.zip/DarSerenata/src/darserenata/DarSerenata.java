/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package darserenata;

import java.util.Vector;

/**
 *
 * @author amartinez
 */
public class DarSerenata {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      
       //Array grupo de musicos
       Musico serenata[];
       serenata = new Musico[20];
       serenata[0]= new Musico(1,"Carmen Aldana");
       serenata[1]= new Musico(2,"Andres Martinez");
       serenata[2]= new Musico(3,"Juan Carlos");
       serenata[3]= new Musico(4,"J balvin");
       serenata[4]= new Musico(5,"Vicente Fernandez");
       serenata[5]= new Musico(6,"Ana Gabriel");
       serenata[6]= new Musico(7,"Nicky Jam");
       serenata[7]= new Musico(8,"Alzate");
       serenata[8]= new Musico(9,"Leo Dan");
       serenata[9]= new Musico(10,"Alejandro Daza");
       //Array grupo de instrumentos
       Instrumento instrumentos[];
       instrumentos = new Instrumento[20];
       instrumentos[0] = new Instrumento(1,"Guitarra", "cuerda");
       instrumentos[1] = new Instrumento(2,"Bajo", "cuerda");
       instrumentos[2] = new Instrumento(3,"Violín", "cuerda");
       instrumentos[3] = new Instrumento(4,"Flauta", "viento");
       instrumentos[4] = new Instrumento(5,"Cantante", "");
       instrumentos[5] = new Instrumento(6,"Cantante", "");
       instrumentos[6] = new Instrumento(7,"Cantante", "");
       instrumentos[7] = new Instrumento(8,"Platillos", "Percusión");
       instrumentos[8] = new Instrumento(9,"Trompeta", "viento");
       instrumentos[9] = new Instrumento(10,"Tambor", "Percusión");
       

       

       System.out.println("");
        //Incializamos Formulario enviamos músicos
       NewJFrame formulario = new NewJFrame(serenata,instrumentos);
       formulario.setVisible(true);


    }
    
}
