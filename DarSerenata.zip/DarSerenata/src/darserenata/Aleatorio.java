/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package darserenata;

/**
 *
 * @author amartinez
 */
public class Aleatorio {
    int num;
    
    public Aleatorio(int num){
    this.num=num;
    }
    public int retornaAleatorio(){
    int numAleatorio;
    numAleatorio = (int) (Math.random() * this.num) + 1;
    return numAleatorio;
    }
}
